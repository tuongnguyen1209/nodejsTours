module.exports = {
  port: process.env.PORT || 7000,
};
